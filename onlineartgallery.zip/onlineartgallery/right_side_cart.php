<div class="col-md-3 my_cart_container">
	<div class="my_cart">
        <h3>MyCart</h3>
		<div class="cart_items">
			<ol>
				<li><img src="images/volcano.jpeg" alt="Mayon Volcano" class="my_cart_items"> <span class="my_cart_items_title">Mayon Volcano</span> <span class="my_cart_items_price">Php 5000</span></li>
            </ol>
        </div>
	</div>
</div>	